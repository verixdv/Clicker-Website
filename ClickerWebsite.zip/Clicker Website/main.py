import telebot
import random
from flask import Flask, request, redirect, jsonify, send_from_directory
import threading
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import sqlite3
import os

# Замените на ваш токен
API_TOKEN = '8168734913:AAEjBE2wY0Be3w-pvQZtxcf12DjqvyLIO_k'

bot = telebot.TeleBot(API_TOKEN)

app = Flask(__name__)

current_code = None

def get_db_connection():
    conn = sqlite3.connect('users.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        first_name TEXT,
        balance INTEGER DEFAULT 0,
        username TEXT,
        upgrade_level INTEGER DEFAULT 0
    )
    ''')
    conn.commit()
    conn.close()

def generate_code():
    return ''.join(random.choices('0123456789', k=6))

@app.route('/profile/<int:user_id>')
def show_profile(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT first_name, balance, upgrade_level FROM users WHERE user_id = ?', (user_id,))
    user_data = cursor.fetchone()
    conn.close()

    if user_data:
        first_name, balance, upgrade_level = user_data
        profile_photo_url = "/static/icon.png"  
        upgrade_price = 100 * (upgrade_level + 1)

        return f"""
        <html>
            <head>
                <style>
                    body {{
                        background: linear-gradient(135deg, #6a11cb, #2575fc);
                        color: white;
                        font-family: Arial, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }}
                    .profile-container {{
                        text-align: center;
                        background: rgba(0, 0, 0, 0.7);
                        padding: 40px;
                        border-radius: 15px;
                        box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
                    }}
                    .balance-button {{
                        background-color: #4CAF50;
                        color: white;
                        padding: 20px 40px;
                        border: none;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 24px;
                        margin-top: 30px;
                        transition: background-color 0.3s ease;
                    }}
                    .balance-button:hover {{
                        background-color: #45a049;
                    }}
                    .upgrade-button {{
                        background-color: #FFA500;
                        color: white;
                        padding: 20px 40px;
                        border: none;
                        border-radius: 10px;
                        cursor: pointer;
                        font-size: 24px;
                        margin-top: 30px;
                        transition: background-color 0.3s ease;
                    }}
                    .upgrade-button:hover {{
                        background-color: #cc8400;
                    }}
                    .balance-value {{
                        font-size: 48px;
                        margin: 20px 0;
                    }}
                    .profile-image {{
                        width: 200px;
                        height: 200px;
                        border-radius: 50%;
                        object-fit: cover;
                        margin-bottom: 20px;
                    }}
                </style>
                <script>
                    function increaseBalance(userId) {{
                        fetch(`/increase_balance/${{userId}}`, {{ method: 'POST' }})
                            .then(response => response.json())
                            .then(data => {{
                                if (data.success) {{
                                    document.getElementById('balance').innerText = data.balance;
                                }}
                            }});
                    }}

                    function upgrade(userId) {{
                        fetch(`/upgrade/${{userId}}`, {{ method: 'POST' }})
                            .then(response => response.json())
                            .then(data => {{
                                if (data.success) {{
                                    document.getElementById('balance').innerText = data.balance;
                                    document.getElementById('upgrade-price').innerText = data.upgrade_price;
                                }}
                            }});
                    }}
                </script>
            </head>
            <body>
                <div class="profile-container">
                    <img src="{profile_photo_url}" alt="Profile Image" class="profile-image">
                    <h1 style="font-size: 48px;">Профиль</h1>
                    <h2 style="font-size: 36px;">Имя: {first_name}</h2>
                    <h2 style="font-size: 36px;">Баланс: <span id="balance">{balance}</span></h2>
                    <h2 style="font-size: 36px;">Уровень улучшения: {upgrade_level}</h2>
                    <button onclick="increaseBalance({user_id})" class="balance-button">Увеличить баланс на +{upgrade_level + 1}</button>
                    <button onclick="upgrade({user_id})" class="upgrade-button">Улучшить | Цена: <span id="upgrade-price">{upgrade_price}</span></button>
                </div>
            </body>
        </html>
        """
    else:
        return "Пользователь не найден."

@app.route('/increase_balance/<int:user_id>', methods=['POST'])
def increase_balance(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT upgrade_level FROM users WHERE user_id = ?', (user_id,))
    upgrade_level = cursor.fetchone()[0]
    increment = upgrade_level + 1
    cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (increment, user_id))
    conn.commit()
    cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
    new_balance = cursor.fetchone()[0]
    conn.close()
    return jsonify({'success': True, 'balance': new_balance})

@app.route('/upgrade/<int:user_id>', methods=['POST'])
def upgrade(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT balance, upgrade_level FROM users WHERE user_id = ?', (user_id,))
    balance, upgrade_level = cursor.fetchone()
    upgrade_price = 100 * (upgrade_level + 1)

    if balance >= upgrade_price:
        cursor.execute('UPDATE users SET balance = balance - ?, upgrade_level = upgrade_level + 1 WHERE user_id = ?', (upgrade_price, user_id))
        conn.commit()
        cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
        new_balance = cursor.fetchone()[0]
        new_upgrade_price = 100 * (upgrade_level + 2)
        conn.close()
        return jsonify({'success': True, 'balance': new_balance, 'upgrade_price': new_upgrade_price})
    else:
        conn.close()
        return jsonify({'success': False, 'message': 'Недостаточно средств'})

@app.route('/auth')
def auth_page():
    global current_code
    if current_code:
        return f"""
        <html>
            <body>
                <div style="text-align: center; margin-top: 50px;">
                    <a href="https://t.me/Robot_TestTg_Robot?start={current_code}" style="font-size: 24px; padding: 15px 30px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Авторизоваться</a>
                </div>
            </body>
        </html>
        """
    else:
        return "Код не сгенерирован."

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

def run_flask():
    app.run(host='127.0.0.1', port=5000) 

@bot.message_handler(commands=['start'])
def send_welcome(message):
    global current_code
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    username = message.from_user.username

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
    user = cursor.fetchone()

    if user: 
        keyboard = InlineKeyboardMarkup()
        button = InlineKeyboardButton(text="Профиль", url=f"http://127.0.0.1:5000/profile/{user_id}")
        keyboard.add(button)
        bot.reply_to(message, "Вы уже авторизованы. Нажмите кнопку ниже, чтобы посмотреть профиль:", reply_markup=keyboard)
    else: 
        if len(message.text.split()) > 1:  
            user_code = message.text.split()[1]
            if user_code == current_code: 
                cursor.execute('INSERT INTO users (user_id, first_name, username) VALUES (?, ?, ?)', (user_id, first_name, username))
                conn.commit()
                bot.reply_to(message, "Код верный! Вы успешно авторизованы.")
            else:
                bot.reply_to(message, "Неверный код. Попробуйте снова.")
        else:  
            current_code = generate_code() 

            keyboard = InlineKeyboardMarkup()
            button = InlineKeyboardButton(text="Авторизоваться", url=f"http://127.0.0.1:5000/auth")
            keyboard.add(button)

            bot.reply_to(message, "Нажмите кнопку ниже, чтобы авторизоваться:", reply_markup=keyboard)

    conn.close()

if __name__ == '__main__':
    init_db()

    if not os.path.exists('static'):
        os.makedirs('static')

    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True
    flask_thread.start()

    bot.polling(none_stop=True)